# IT-R

This is a collection of notes and code resources for installing RStudio Server and configuring your Linux system in a way that is convenient for teaching statistics.
